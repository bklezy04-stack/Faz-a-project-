// IIFE: تنفيذ الكود مباشرة بدون تلويث الـ global scope
(async function () {
  // جلب التوكن من localStorage (من auth.js)
  const token = getToken();

  // إذا ما في توكن → رجّع المستخدم لصفحة الدخول
  if (!token) return redirectToLogin();

  // =========================
  // 1️⃣ التحقق أن المستخدم Admin
  // =========================
  try {
    // طلب بيانات المستخدم من السيرفر باستخدام التوكن
    const res = await fetch("http://localhost:5000/users/api/profile", {
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();

    // إذا الطلب فشل أو الدور مش admin → ممنوع الدخول
    if (!res.ok || data.data.role !== "admin") {
      throw new Error("Not admin");
    }
  } catch {
    // في حال:
    // - التوكن منتهي
    // - التوكن غير صالح
    // - المستخدم ليس admin
    clearToken();
    return redirectToLogin();
  }

  // =========================
  // 2️⃣ تحميل المستخدمين
  // =========================
  async function loadUsers() {
    // جلب جميع المستخدمين (API محمي – admin فقط)
    const res = await fetch("http://localhost:5000/users/api", {
      headers: { Authorization: `Bearer ${getToken()}` },
    });

    const data = await res.json();

    // جسم الجدول
    const tbody = document.getElementById("usersTable");
    tbody.innerHTML = "";

    // عرض المستخدمين داخل الجدول
    data.data.forEach((user, index) => {
      tbody.innerHTML += `
        <tr>
          <td>${index + 1}</td>
          <td>${user.name}</td>
          <td>${user.email}</td>
          <td>${user.role}</td>
          <td>
            <button class="btn delete" data-id="${user._id}">
              حذف
            </button>
          </td>
        </tr>
      `;
    });

    // ربط أزرار الحذف
    attachDeleteUser();
  }

  // =========================
  // 3️⃣ حذف مستخدم
  // =========================
  function attachDeleteUser() {
    // لكل زر حذف داخل جدول المستخدمين
    document.querySelectorAll("#usersTable .delete").forEach((btn) => {
      btn.addEventListener("click", async () => {
        // تأكيد الحذف
        if (!confirm("هل أنت متأكد من حذف المستخدم؟")) return;

        // ID المستخدم
        const id = btn.dataset.id;

        // إرسال طلب DELETE
        await fetch(`http://localhost:5000/users/api/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${getToken()}` },
        });

        // إعادة تحميل المستخدمين بعد الحذف
        loadUsers();
      });
    });
  }

  // =========================
  // 4️⃣ تحميل البلاغات + تعديل الحالة
  // =========================
  async function loadReports() {
    // جلب جميع البلاغات
    const res = await fetch("http://localhost:5000/reports/api", {
      headers: { Authorization: `Bearer ${getToken()}` },
    });

    const data = await res.json();

    // جسم جدول البلاغات
    const tbody = document.getElementById("reportsTable");
    tbody.innerHTML = "";

    // عرض البلاغات
    data.data.forEach((report, index) => {
      tbody.innerHTML += `
        <tr>
          <td>${index + 1}</td>
          <td>${report.title}</td>

          <!-- عرض الحالة الحالية -->
          <td>
            <span class="status-badge status-${report.status}">
              ${report.status}
            </span>
          </td>

          <!-- قائمة تغيير الحالة -->
          <td>
            <select class="status-select" data-id="${report._id}">
              <option value="pending" ${
                report.status === "pending" ? "selected" : ""
              }>قيد الانتظار</option>

              <option value="completed" ${
                report.status === "completed" ? "selected" : ""
              }>مكتمل</option>
            </select>
          </td>

          <!-- زر حذف البلاغ -->
          <td>
            <button class="btn delete" data-id="${report._id}">
              حذف
            </button>
          </td>
        </tr>
      `;
    });

    // ربط أزرار الحذف وتغيير الحالة
    attachDeleteReport();
    attachUpdateStatus();
  }

  // =========================
  // 5️⃣ حذف بلاغ
  // =========================
  function attachDeleteReport() {
    document.querySelectorAll("#reportsTable .delete").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("هل أنت متأكد من حذف البلاغ؟")) return;

        const id = btn.dataset.id;

        await fetch(`http://localhost:5000/reports/api/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${getToken()}` },
        });

        // إعادة تحميل البلاغات
        loadReports();
      });
    });
  }

  // =========================
  // 6️⃣ تعديل حالة البلاغ
  // =========================
  function attachUpdateStatus() {
    // لكل select خاص بالحالة
    document.querySelectorAll(".status-select").forEach((select) => {
      select.addEventListener("change", async () => {
        const reportId = select.dataset.id;
        const newStatus = select.value;

        // إرسال PATCH لتحديث الحالة
        await fetch(`http://localhost:5000/reports/api/${reportId}/status`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${getToken()}`,
          },
          body: JSON.stringify({ status: newStatus }),
        });

        // إعادة تحميل البلاغات لعرض الحالة الجديدة
        loadReports();
      });
    });
  }

  // =========================
  // 7️⃣ تسجيل الخروج
  // =========================
  document.getElementById("logoutBtn").addEventListener("click", () => {
    clearToken();
    redirectToLogin();
  });

  // =========================
  // 🚀 تشغيل الصفحة
  // =========================
  loadUsers(); // تحميل المستخدمين
  loadReports(); // تحميل البلاغات
})();
