/*document.getElementById("signupForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const passwordConfirm = document.getElementById("passwordConfirm").value;
  const role = document.getElementById("role").value;

  // Validation
  if (!name || !email || !password || !passwordConfirm || !role) {
    alert("❌ جميع الحقول مطلوبة");
    return;
  }

  if (password !== passwordConfirm) {
    alert("❌ كلمات المرور غير متطابقة");
    return;
  }

  try {
    const res = await fetch("http://localhost:5000/users/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        email,
        password,
        passwordConfirm,
        role,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || "فشل إنشاء الحساب");
    }

    // 1️⃣ حفظ التوكن
    setToken(data.token);

    // 2️⃣ الوصول الصحيح للمستخدم
    const user = data.data.user || data.data;

    // 3️⃣ حفظ الدور (اختياري)
    localStorage.setItem("role", user.role);

    // 4️⃣ Redirect
    if (user.role === "admin") {
      window.location.href = "admin.html";
    } else {
      window.location.href = "overview.html";
    }
  } catch (err) {
    alert("❌ " + err.message);
  }
});
*/

/**
 * register.js
 * ملف إدارة تسجيل المستخدمين الجدد لمنصة فزعة
 */

// ================ متغيرات عامة ================
let isSubmitting = false;
const API_BASE_URL = "http://localhost:5000"; // يمكن تغييره حسب البيئة

// ================ الدوال المساعدة ================

/**
 * التحقق من صحة البريد الإلكتروني
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * حساب قوة كلمة المرور
 * @returns {number} درجة القوة من 0 إلى 4
 */
function calculatePasswordStrength(password) {
  let score = 0;

  if (password.length >= 8) score++;
  if (password.length >= 12) score++;

  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;

  if (/\d/.test(password)) score++;

  if (/[^A-Za-z0-9]/.test(password)) score++;

  return score;
}

/**
 * تحديث مؤشر قوة كلمة المرور
 */
function updatePasswordStrength(password) {
  const strengthMeter = document.getElementById("strengthMeter");
  const strengthText = document.getElementById("strengthText");

  if (!strengthMeter || !strengthText) return;

  strengthMeter.className = "strength-meter";

  if (password.length === 0) {
    strengthText.textContent = "أدخل كلمة المرور";
    strengthText.style.color = "var(--gray)";
    return;
  }

  const strength = calculatePasswordStrength(password);

  if (strength < 2) {
    strengthMeter.classList.add("weak");
    strengthText.textContent = "قوة كلمة المرور: ضعيفة";
    strengthText.style.color = "var(--danger)";
  } else if (strength < 4) {
    strengthMeter.classList.add("medium");
    strengthText.textContent = "قوة كلمة المرور: متوسطة";
    strengthText.style.color = "var(--warning)";
  } else {
    strengthMeter.classList.add("strong");
    strengthText.textContent = "قوة كلمة المرور: قوية";
    strengthText.style.color = "var(--secondary)";
  }
}

/**
 * التحقق من تطابق كلمتي المرور
 * @returns {boolean} true إذا كانتا متطابقتين
 */
function validatePasswordMatch() {
  const password = document.getElementById("password").value;
  const confirm = document.getElementById("passwordConfirm").value;
  const errorElement = document.getElementById("passwordConfirmError");

  if (!errorElement) return true;

  if (confirm && password !== confirm) {
    document.getElementById("passwordConfirm").classList.add("error");
    errorElement.textContent = "كلمتا المرور غير متطابقتين";
    errorElement.classList.add("show");
    return false;
  } else {
    document.getElementById("passwordConfirm").classList.remove("error");
    errorElement.classList.remove("show");
    return true;
  }
}

/**
 * إظهار رسالة خطأ
 */
function showError(message, duration = 5000) {
  const alertError = document.getElementById("alertError");
  const errorText = document.getElementById("errorText");

  if (alertError && errorText) {
    errorText.textContent = message;
    alertError.style.display = "block";

    // إخفاء رسالة النجاح إذا كانت ظاهرة
    const alertSuccess = document.getElementById("alertSuccess");
    if (alertSuccess) alertSuccess.style.display = "none";

    // إخفاء تلقائي بعد مدة
    if (duration > 0) {
      setTimeout(() => {
        alertError.style.display = "none";
      }, duration);
    }
  } else {
    // Fallback إذا لم تكن العناصر موجودة
    console.error("Error:", message);
    alert("❌ " + message);
  }
}

/**
 * إظهار رسالة نجاح
 */
function showSuccess(message, duration = 3000) {
  const alertSuccess = document.getElementById("alertSuccess");
  const successText = document.getElementById("successText");

  if (alertSuccess && successText) {
    successText.textContent = message;
    alertSuccess.style.display = "block";

    // إخفاء رسالة الخطأ إذا كانت ظاهرة
    const alertError = document.getElementById("alertError");
    if (alertError) alertError.style.display = "none";

    // إخفاء تلقائي بعد مدة
    if (duration > 0) {
      setTimeout(() => {
        alertSuccess.style.display = "none";
      }, duration);
    }
  }
}

/**
 * تعطيل/تفعيل زر الإرسال
 */
function toggleSubmitButton(disabled) {
  const submitBtn = document.getElementById("submitBtn");
  if (submitBtn) {
    submitBtn.disabled = disabled;
    if (disabled) {
      submitBtn.classList.add("loading");
      submitBtn.innerHTML =
        '<span class="loading-spinner"></span> جاري الإنشاء...';
    } else {
      submitBtn.classList.remove("loading");
      submitBtn.innerHTML = '<i class="fas fa-user-plus"></i> إنشاء حساب جديد';
    }
  }
}

/**
 * تنظيف رسائل الأخطاء
 */
function clearErrors() {
  // تنظيف رسائل الخطأ
  document.querySelectorAll(".error-message").forEach((el) => {
    el.classList.remove("show");
  });

  // تنظيف حدود الحقول
  document.querySelectorAll(".form-control").forEach((el) => {
    el.classList.remove("error");
  });

  // إخفاء الرسائل العامة
  const alertError = document.getElementById("alertError");
  const alertSuccess = document.getElementById("alertSuccess");
  if (alertError) alertError.style.display = "none";
  if (alertSuccess) alertSuccess.style.display = "none";
}

/**
 * التحقق من النموذج قبل الإرسال
 * @returns {boolean} true إذا كان النموذج صالحاً
 */
function validateForm() {
  let isValid = true;

  // تنظيف الأخطاء السابقة
  clearErrors();

  // التحقق من الاسم
  const nameInput = document.getElementById("name");
  const name = nameInput ? nameInput.value.trim() : "";
  const nameError = document.getElementById("nameError");

  if (!name || name.length < 2) {
    if (nameInput) nameInput.classList.add("error");
    if (nameError) {
      nameError.textContent = "الاسم يجب أن يكون على الأقل حرفين";
      nameError.classList.add("show");
    }
    isValid = false;
  }

  // التحقق من البريد الإلكتروني
  const emailInput = document.getElementById("email");
  const email = emailInput ? emailInput.value.trim() : "";
  const emailError = document.getElementById("emailError");

  if (!email || !isValidEmail(email)) {
    if (emailInput) emailInput.classList.add("error");
    if (emailError) {
      emailError.textContent = "البريد الإلكتروني غير صحيح";
      emailError.classList.add("show");
    }
    isValid = false;
  }

  // التحقق من كلمة المرور
  const passwordInput = document.getElementById("password");
  const password = passwordInput ? passwordInput.value : "";
  const passwordError = document.getElementById("passwordError");

  if (!password || password.length < 8) {
    if (passwordInput) passwordInput.classList.add("error");
    if (passwordError) {
      passwordError.textContent = "كلمة المرور يجب أن تكون 8 أحرف على الأقل";
      passwordError.classList.add("show");
    }
    isValid = false;
  }

  // التحقق من تطابق كلمتي المرور
  if (!validatePasswordMatch()) {
    isValid = false;
  }

  // التحقق من نوع الحساب
  const roleInput = document.getElementById("role");
  const role = roleInput ? roleInput.value : "";
  const roleError = document.getElementById("roleError");

  if (!role || (role !== "user" && role !== "volunteer")) {
    if (roleError) {
      roleError.textContent = "يرجى اختيار نوع الحساب";
      roleError.classList.add("show");
    }
    isValid = false;
  }

  // التحقق من قبول الشروط
  const termsInput = document.getElementById("terms");
  const termsError = document.getElementById("termsError");

  if (!termsInput || !termsInput.checked) {
    if (termsError) {
      termsError.textContent = "يجب الموافقة على الشروط والأحكام";
      termsError.classList.add("show");
    }
    isValid = false;
  }

  return isValid;
}

/**
 * حفظ التوكن في localStorage
 */
function setToken(token) {
  if (token) {
    localStorage.setItem("token", token);
  }
}

/**
 * حفظ بيانات المستخدم في localStorage
 */
function setUserData(userData) {
  if (userData) {
    localStorage.setItem("user", JSON.stringify(userData));
    if (userData.role) {
      localStorage.setItem("role", userData.role);
    }
  }
}

/**
 * إعادة التوجيه حسب دور المستخدم
 */
function redirectUser(role) {
  switch (role) {
    case "admin":
      window.location.href = "admin.html";
      break;
    case "volunteer":
      window.location.href = "overview.html";
      break;
    default:
      window.location.href = "overview.html";
  }
}

// ================ إرسال النموذج ================

/**
 * معالجة إرسال نموذج التسجيل
 */
async function handleSignupSubmit(e) {
  e.preventDefault();

  // منع إرسال متعدد
  if (isSubmitting) return;

  // التحقق من صحة النموذج
  if (!validateForm()) {
    return;
  }

  // جمع البيانات
  const formData = {
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    password: document.getElementById("password").value,
    passwordConfirm: document.getElementById("passwordConfirm").value,
    role: document.getElementById("role").value,
    phone: "+966501234567", // يمكن تغييره إذا أضفت حقل للهاتف
  };

  // تعطيل الزر وعرض حالة التحميل
  isSubmitting = true;
  toggleSubmitButton(true);

  try {
    // إرسال الطلب إلى الخادم
    const response = await fetch(`${API_BASE_URL}/users/api/signup`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    if (!response.ok) {
      // معالجة أخطاء الخادم
      let errorMessage = "فشل إنشاء الحساب";

      if (data.message) {
        errorMessage = data.message;
      } else if (data.errors && Array.isArray(data.errors)) {
        // عرض أخطاء التحقق من الخادم
        data.errors.forEach((error) => {
          const fieldError = document.getElementById(`${error.field}Error`);
          if (fieldError) {
            fieldError.textContent = error.message;
            fieldError.classList.add("show");

            const fieldInput = document.getElementById(error.field);
            if (fieldInput) fieldInput.classList.add("error");
          }
        });
        errorMessage = "يرجى تصحيح الأخطاء أعلاه";
      }

      throw new Error(errorMessage);
    }

    // التسجيل الناجح
    console.log("تم التسجيل بنجاح:", data);

    // حفظ التوكن وبيانات المستخدم
    if (data.token) {
      setToken(data.token);
    }

    // استخراج بيانات المستخدم من الاستجابة
    const user = data.data?.user || data.data || data.user;
    if (user) {
      setUserData(user);
    }

    // عرض رسالة النجاح
    showSuccess("تم إنشاء حسابك بنجاح! سيتم توجيهك خلال ثوانٍ...");

    // إعادة التوجيه بعد تأخير قصير
    setTimeout(() => {
      redirectUser(user?.role || formData.role);
    }, 2000);
  } catch (error) {
    console.error("خطأ في التسجيل:", error);

    // عرض رسالة الخطأ
    if (error.name === "TypeError" && error.message.includes("fetch")) {
      showError("تعذر الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت.");
    } else {
      showError(error.message || "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.");
    }

    // إعادة تفعيل الزر
    isSubmitting = false;
    toggleSubmitButton(false);
  }
}

// ================ تهيئة الأحداث ================

/**
 * تهيئة جميع مستمعي الأحداث
 */
function initializeEventListeners() {
  // النموذج الرئيسي
  const signupForm = document.getElementById("signupForm");
  if (signupForm) {
    signupForm.addEventListener("submit", handleSignupSubmit);
  }

  // تحديث قوة كلمة المرور في الوقت الفعلي
  const passwordInput = document.getElementById("password");
  if (passwordInput) {
    passwordInput.addEventListener("input", function () {
      updatePasswordStrength(this.value);
    });
  }

  // التحقق من تطابق كلمتي المرور في الوقت الفعلي
  const passwordConfirmInput = document.getElementById("passwordConfirm");
  if (passwordConfirmInput) {
    passwordConfirmInput.addEventListener("input", validatePasswordMatch);
  }

  if (passwordInput) {
    passwordInput.addEventListener("input", validatePasswordMatch);
  }

  // تبديل إظهار/إخفاء كلمة المرور
  const togglePasswordBtn = document.getElementById("togglePassword");
  if (togglePasswordBtn) {
    togglePasswordBtn.addEventListener("click", function () {
      const passwordField = document.getElementById("password");
      if (passwordField) {
        const type =
          passwordField.getAttribute("type") === "password"
            ? "text"
            : "password";
        passwordField.setAttribute("type", type);
        this.innerHTML =
          type === "password"
            ? '<i class="fas fa-eye"></i>'
            : '<i class="fas fa-eye-slash"></i>';
      }
    });
  }

  // تبديل إظهار/إخفاء تأكيد كلمة المرور
  const togglePasswordConfirmBtn = document.getElementById(
    "togglePasswordConfirm"
  );
  if (togglePasswordConfirmBtn) {
    togglePasswordConfirmBtn.addEventListener("click", function () {
      const passwordConfirmField = document.getElementById("passwordConfirm");
      if (passwordConfirmField) {
        const type =
          passwordConfirmField.getAttribute("type") === "password"
            ? "text"
            : "password";
        passwordConfirmField.setAttribute("type", type);
        this.innerHTML =
          type === "password"
            ? '<i class="fas fa-eye"></i>'
            : '<i class="fas fa-eye-slash"></i>';
      }
    });
  }

  // اختيار نوع الحساب
  const roleOptions = document.querySelectorAll(".role-option");
  const roleInput = document.getElementById("role");

  if (roleOptions.length > 0 && roleInput) {
    roleOptions.forEach((option) => {
      option.addEventListener("click", function () {
        // إزالة التحديد من جميع الخيارات
        roleOptions.forEach((opt) => opt.classList.remove("selected"));

        // إضافة التحديد للخيار المختار
        this.classList.add("selected");

        // تحديث حقل الإدخال المخفي
        roleInput.value = this.dataset.role;
      });
    });
  }
}

// ================ تهيئة الصفحة ================

/**
 * تهيئة الصفحة عند التحميل
 */
function initializePage() {
  console.log("تهيئة صفحة التسجيل...");

  // التأكد من وجود العناصر الضرورية
  if (!document.getElementById("signupForm")) {
    console.warn("لم يتم العثور على نموذج التسجيل");
    return;
  }

  // تهيئة مستمعي الأحداث
  initializeEventListeners();

  // تأثيرات بصرية للبطاقة
  const card = document.querySelector(".card");
  if (card) {
    card.style.opacity = "0";
    card.style.transform = "translateY(20px)";

    setTimeout(() => {
      card.style.transition = "opacity 0.5s ease, transform 0.5s ease";
      card.style.opacity = "1";
      card.style.transform = "translateY(0)";
    }, 100);
  }

  // التحقق من وجود توكن (إذا كان مسجلاً دخولاً بالفعل)
  const token = localStorage.getItem("token");
  if (token) {
    console.log("المستخدم مسجل دخول بالفعل");
    // يمكن إضافة توجيه تلقائي هنا إذا لزم
  }

  console.log("تم تهيئة صفحة التسجيل بنجاح");
}

// ================ بدء التشغيل ================

// انتظار تحميل DOM
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializePage);
} else {
  initializePage();
}

// ================ تصدير للاستخدام في البيئات النمطية ================
// (اختياري - إذا كنت تستخدم نظام وحدات)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    isValidEmail,
    calculatePasswordStrength,
    validatePasswordMatch,
    validateForm,
    handleSignupSubmit,
  };
}
