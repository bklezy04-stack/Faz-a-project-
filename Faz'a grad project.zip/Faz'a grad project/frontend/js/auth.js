// ==================================================
// 🌐 عنوان السيرفر الأساسي
// ==================================================
const API_URL = "http://localhost:5000";

// ==================================================
// 🔐 Token helpers
// ==================================================

/**
 * تخزين JWT في localStorage
 * يتم استدعاؤها بعد تسجيل الدخول
 */
function setToken(token) {
  localStorage.setItem("token", token);
}

/**
 * جلب التوكن من localStorage
 * تستخدم قبل أي طلب محمي
 */
function getToken() {
  return localStorage.getItem("token");
}

/**
 * تسجيل الخروج:
 * - حذف التوكن
 * - إعادة التوجيه للصفحة الرئيسية
 */
function logout() {
  localStorage.removeItem("token");
  window.location.href = "overview.html";
}

// ==================================================
// 🔁 Auth Fetch Wrapper
// ==================================================

/**
 * دالة مغلفة لـ fetch:
 * - تضيف Authorization تلقائيًا
 * - تتعامل مع JSON
 * - توحّد معالجة الأخطاء
 *
 * @param {string} url - مسار الـ API (بدون الدومين)
 * @param {object} options - إعدادات fetch
 */
async function authFetch(url, options = {}) {
  const token = getToken();

  // دمج الهيدرز الافتراضية مع أي هيدرز إضافية
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };

  // إذا في توكن → أضفه للهيدر
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  // تنفيذ الطلب
  const res = await fetch(API_URL + url, {
    ...options,
    headers,
  });

  // محاولة قراءة الرد كـ JSON
  let data;
  try {
    data = await res.json();
  } catch {
    // السيرفر رجّع رد غير مفهوم
    throw new Error("Invalid server response");
  }

  // إذا الرد مش ناجح → ارمي خطأ
  if (!res.ok) {
    throw new Error(data.message || "حدث خطأ");
  }

  // إرجاع البيانات النهائية
  return data;
}

// ==================================================
// 🛡️ Protect Pages (بدون redirect loop)
// ==================================================

/**
 * حماية الصفحات حسب الدور
 *
 * @param {Array} allowedRoles - الأدوار المسموحة للصفحة
 * @returns user object أو null
 */
async function protectPage(allowedRoles = []) {
  try {
    // جلب بيانات المستخدم من التوكن
    const data = await authFetch("/users/api/profile");
    const user = data.data;

    // إذا الصفحة محددة أدوار
    // والمستخدم دوره غير مسموح
    if (allowedRoles.length && !allowedRoles.includes(user.role)) {
      alert("❌ غير مصرح لك بدخول هذه الصفحة");
      logout();
      return null;
    }

    // المستخدم مصرح له
    return user;
  } catch (err) {
    /**
     * في حال:
     * - التوكن منتهي
     * - التوكن غير صالح
     * - المستخدم غير مسجل
     *
     * نعمل logout فقط إذا في توكن
     * (لتجنب redirect loop)
     */
    if (getToken()) logout();
    return null;
  }
}

// ==================================================
// 🧭 Navbar Authentication UI
// ==================================================

/**
 * التحكم بعناصر الـ Navbar حسب حالة تسجيل الدخول
 */
function handleNavbarAuth() {
  const token = getToken();

  const loginLink = document.getElementById("loginLink");
  const signupLink = document.getElementById("signupLink");
  const profileLink = document.getElementById("profileLink");
  const logoutLink = document.getElementById("logoutLink");

  // في حال الصفحة ما فيها navbar
  if (!loginLink || !signupLink || !profileLink || !logoutLink) return;

  if (token) {
    // المستخدم مسجل دخول
    loginLink.style.display = "none";
    signupLink.style.display = "none";
    profileLink.style.display = "inline";
    logoutLink.style.display = "inline";
  } else {
    // المستخدم غير مسجل
    loginLink.style.display = "inline";
    signupLink.style.display = "inline";
    profileLink.style.display = "none";
    logoutLink.style.display = "none";
  }
}

// ==================================================
// 🚪 Logout Button Handler (آمن)
// ==================================================

/**
 * ربط زر تسجيل الخروج إن وجد
 */
document.addEventListener("DOMContentLoaded", () => {
  const logoutBtn = document.getElementById("logoutBtn");

  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      logout();
    });
  }
});
