/**
 * =====================================================
 * 📄 report-details.js
 * =====================================================
 * هذا الملف مسؤول عن:
 * - حماية صفحة تفاصيل البلاغ
 * - جلب بيانات المستخدم الحالي
 * - جلب تفاصيل بلاغ معيّن عبر ID من الـ URL
 * - التحكم في الصلاحيات (حذف / إتمام)
 * =====================================================
 */

(async function () {
  // ===============================
  // 🔐 التحقق من وجود توكن
  // ===============================
  const token = localStorage.getItem("token");

  // إذا لم يكن المستخدم مسجّل دخول → تحويل لصفحة login
  if (!token) {
    window.location.href = "login.html";
    return;
  }

  // ===============================
  // 🔎 جلب reportId من الرابط
  // ===============================
  const params = new URLSearchParams(window.location.search);
  const reportId = params.get("id");

  // إذا لم يوجد ID في الرابط
  if (!reportId) {
    alert("❌ لا يوجد بلاغ محدد");
    return;
  }

  // ===============================
  // 📌 عناصر صاحب البلاغ
  // ===============================
  const ownerNameEl = document.getElementById("ownerName");
  const ownerEmailEl = document.getElementById("ownerEmail");
  const ownerRoleEl = document.getElementById("ownerRole");

  // ===============================
  // 📌 عناصر تفاصيل البلاغ
  // ===============================
  const titleEl = document.getElementById("title");
  const descEl = document.getElementById("description");
  const statusEl = document.getElementById("status");
  const createdAtEl = document.getElementById("createdAt");
  const volunteerEl = document.getElementById("volunteer");

  // ===============================
  // 🔘 الأزرار
  // ===============================
  const deleteBtn = document.getElementById("deleteBtn");
  const completeBtn = document.getElementById("completeBtn");

  // ===============================
  // 🧠 متغيرات منطقية
  // ===============================
  let currentUserId = null; // المستخدم الحالي
  let reportOwnerId = null; // صاحب البلاغ

  // =====================================================
  // 1️⃣ جلب بيانات المستخدم الحالي
  // =====================================================
  async function loadCurrentUser() {
    const res = await fetch("http://localhost:5000/users/api/profile", {
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();
    if (!res.ok) throw new Error("Unauthorized");

    // استخراج الدور
    const currentUserRole = data.data.role;

    // فقط admin يرى زر الحذف
    if (currentUserRole !== "admin") {
      deleteBtn.style.display = "none";
    }

    // حفظ ID المستخدم الحالي
    currentUserId = data.data._id;
  }

  // =====================================================
  // 2️⃣ تحميل تفاصيل البلاغ
  // =====================================================
  async function loadReport() {
    try {
      const res = await fetch(`http://localhost:5000/reports/api/${reportId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "فشل جلب البلاغ");

      const report = data.data;

      // حفظ ID صاحب البلاغ
      reportOwnerId = report.user?._id;

      // ===============================
      // 👤 بيانات صاحب البلاغ
      // ===============================
      ownerNameEl.textContent = report.user?.name || "—";
      ownerEmailEl.textContent = report.user?.email || "—";
      ownerRoleEl.textContent = report.user?.role || "—";

      // ===============================
      // 📄 تفاصيل البلاغ
      // ===============================
      titleEl.textContent = report.title || "—";
      descEl.textContent = report.description || "—";
      statusEl.textContent = report.status;
      createdAtEl.textContent = new Date(report.createdAt).toLocaleString();

      // ===============================
      // 🤝 اسم المتطوع (إن وجد)
      // ===============================
      volunteerEl.textContent = report.volunteer?.name || "—";

      // =================================================
      // زر "تمّت المساعدة"
      // يظهر فقط إذا:
      // - الحالة accepted
      // - المستخدم الحالي هو صاحب البلاغ
      // =================================================
      if (report.status === "accepted" && currentUserId === reportOwnerId) {
        completeBtn.style.display = "inline-block";
      } else {
        completeBtn.style.display = "none";
      }
    } catch (err) {
      alert("❌ " + err.message);
    }
  }

  // =====================================================
  // 3️⃣ تأكيد إتمام المساعدة (user فقط)
  // =====================================================
  completeBtn.addEventListener("click", async () => {
    if (!confirm("هل أنت متأكد أن المساعدة تمت؟")) return;

    try {
      const res = await fetch(`http://localhost:5000/reports/api/${reportId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: "completed" }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "فشل تحديث الحالة");

      alert("✅ تم تأكيد إتمام المساعدة");
      window.location.href = "reports.html";
    } catch (err) {
      alert("❌ " + err.message);
    }
  });

  // =====================================================
  // 4️⃣ حذف البلاغ (admin فقط)
  // =====================================================
  deleteBtn.addEventListener("click", async () => {
    if (!confirm("هل أنت متأكد من حذف البلاغ؟")) return;

    try {
      const res = await fetch(`http://localhost:5000/reports/api/${reportId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "فشل حذف البلاغ");

      alert("🗑️ تم حذف البلاغ");
      window.location.href = "reports.html";
    } catch (err) {
      alert("❌ " + err.message);
    }
  });

  // =====================================================
  // 🚀 تشغيل الصفحة
  // =====================================================
  try {
    await loadCurrentUser(); // أولاً: من هو المستخدم؟
    await loadReport(); // ثانياً: ما هو البلاغ؟
  } catch {
    // في حال أي خطأ مصادقة
    window.location.href = "login.html";
  }
})();
