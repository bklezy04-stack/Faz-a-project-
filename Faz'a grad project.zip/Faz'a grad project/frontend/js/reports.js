/**
 * =====================================================
 * 📄 reports.js
 * =====================================================
 * هذا الملف مسؤول عن:
 * - حماية صفحة البلاغات
 * - جلب دور المستخدم الحالي
 * - تحميل جميع البلاغات
 * - عرض البلاغات حسب الدور
 * - قبول البلاغ (volunteer)
 * - حذف البلاغ (admin)
 * - الفلترة والترتيب (status / priority / date)
 * =====================================================
 */

(async function () {
  // ===============================
  // 🔐 التحقق من تسجيل الدخول
  // ===============================
  const token = getToken();
  if (!token) return redirectToLogin();

  let currentUserRole = null; // دور المستخدم الحالي

  // ===============================
  // 🏷️ تحويل مستوى الأولوية إلى عربي
  // ===============================
  const levelMap = {
    low: "منخفض",
    medium: "متوسط",
    high: "عالي",
    critical: "حرج",
  };

  let allReports = []; // تخزين جميع البلاغات (للفلترة لاحقاً)

  // =====================================================
  // 1️⃣ جلب دور المستخدم الحالي
  // =====================================================
  try {
    const res = await fetch("http://localhost:5000/users/api/profile", {
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();
    if (!res.ok) throw new Error("Unauthorized");

    currentUserRole = data.data.role;
  } catch {
    // في حال فشل التحقق → تسجيل خروج
    clearToken();
    return redirectToLogin();
  }

  // =====================================================
  // 2️⃣ جلب جميع البلاغات من السيرفر
  // =====================================================
  async function loadReports() {
    try {
      const res = await fetch("http://localhost:5000/reports/api", {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      if (!res.ok) throw new Error("فشل تحميل البلاغات");

      // حفظ البلاغات كاملة
      allReports = data.data;

      // تطبيق الفلاتر والترتيب
      applyFilters();
    } catch (err) {
      alert("❌ " + err.message);
    }
  }

  // =====================================================
  // 3️⃣ عرض البلاغات في الواجهة
  // =====================================================
  function displayReports(reports) {
    const container = document.getElementById("reportsContainer");
    container.innerHTML = "";

    reports.forEach((report) => {
      const card = document.createElement("div");
      card.className = "card";

      // بناء كرت البلاغ
      card.innerHTML = `
        <!-- مستوى الأولوية -->
        <span class="report-level level-${report.priority || "medium"}">
          ${levelMap[report.priority] || "متوسط"}
        </span>

        <!-- عنوان ووصف البلاغ -->
        <h3>${report.title}</h3>
        <p>${report.description}</p>

        <!-- حالة البلاغ -->
        <p><strong>الحالة:</strong> ${report.status}</p>

        <!-- زر التفاصيل (لكل المستخدمين) -->
        <button class="secondary detailsBtn" data-id="${report._id}">
          عرض التفاصيل
        </button>

        <!-- زر قبول البلاغ (volunteer فقط + pending) -->
        ${
          currentUserRole === "volunteer" && report.status === "pending"
            ? `<button class="acceptBtn" data-id="${report._id}">
                 قبول البلاغ
               </button>`
            : ""
        }

        <!-- زر حذف البلاغ (admin فقط) -->
        ${
          currentUserRole === "admin"
            ? `<button class="danger deleteBtn" data-id="${report._id}">
                 حذف البلاغ
               </button>`
            : ""
        }
      `;

      container.appendChild(card);
    });

    // ربط الأحداث بعد إنشاء العناصر
    attachEvents();
  }

  // =====================================================
  // 4️⃣ ربط الأحداث (تفاصيل / قبول / حذف)
  // =====================================================
  function attachEvents() {
    // عرض تفاصيل البلاغ
    document.querySelectorAll(".detailsBtn").forEach((btn) => {
      btn.addEventListener("click", () => {
        window.location.href = `report-details.html?id=${btn.dataset.id}`;
      });
    });

    // قبول البلاغ (volunteer)
    document.querySelectorAll(".acceptBtn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const res = await fetch(
            `http://localhost:5000/reports/api/${btn.dataset.id}`,
            {
              method: "PATCH",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({ status: "accepted" }),
            }
          );

          if (!res.ok) throw new Error("فشل قبول البلاغ");

          // إعادة تحميل البلاغات
          loadReports();
        } catch (err) {
          alert("❌ " + err.message);
        }
      });
    });

    // حذف البلاغ (admin)
    document.querySelectorAll(".deleteBtn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("هل أنت متأكد من حذف البلاغ؟")) return;

        try {
          const res = await fetch(
            `http://localhost:5000/reports/api/${btn.dataset.id}`,
            {
              method: "DELETE",
              headers: { Authorization: `Bearer ${token}` },
            }
          );

          if (!res.ok) throw new Error("فشل حذف البلاغ");

          loadReports();
        } catch (err) {
          alert("❌ " + err.message);
        }
      });
    });
  }

  // =====================================================
  // 5️⃣ الفلاتر + الترتيب
  // =====================================================
  function applyFilters() {
    // قراءة قيم الفلاتر
    const statusValue = document.getElementById("statusFilter")?.value || "all";
    const priorityValue =
      document.getElementById("priorityFilter")?.value || "all";
    const dateSort = document.getElementById("dateSort")?.value || "newest";

    let filteredReports = [...allReports];

    // فلترة حسب الحالة
    if (statusValue !== "all") {
      filteredReports = filteredReports.filter(
        (report) => report.status === statusValue
      );
    }

    // فلترة حسب الأولوية
    if (priorityValue !== "all") {
      filteredReports = filteredReports.filter(
        (report) => report.priority === priorityValue
      );
    }

    // ترتيب حسب التاريخ
    filteredReports.sort((a, b) => {
      const dateA = new Date(a.createdAt);
      const dateB = new Date(b.createdAt);
      return dateSort === "newest" ? dateB - dateA : dateA - dateB;
    });

    // عرض النتيجة النهائية
    displayReports(filteredReports);
  }

  // =====================================================
  // 🎛️ ربط عناصر الفلترة
  // =====================================================
  document
    .getElementById("statusFilter")
    ?.addEventListener("change", applyFilters);

  document
    .getElementById("priorityFilter")
    ?.addEventListener("change", applyFilters);

  document.getElementById("dateSort")?.addEventListener("change", applyFilters);

  // =====================================================
  // 🚀 بدء التشغيل
  // =====================================================
  loadReports();
})();
