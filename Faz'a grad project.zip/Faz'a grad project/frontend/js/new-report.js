// ربط حدث الإرسال مع الفورم
document
  .getElementById("reportForm")
  .addEventListener("submit", async function (e) {
    // منع إعادة تحميل الصفحة
    e.preventDefault();

    // جلب التوكن (من auth.js)
    const token = getToken();

    // إذا المستخدم غير مسجّل → توجيه لصفحة الدخول
    if (!token) return redirectToLogin();

    // جلب القيم من الحقول
    const title = document.getElementById("title").value.trim();
    const description = document.getElementById("description").value.trim();

    // مستوى الأولوية (low / medium / high / critical)
    const priority = document.getElementById("priority").value;

    try {
      // =================================================
      // إرسال طلب إنشاء البلاغ
      // =================================================
      const res = await fetch("http://localhost:5000/reports/api", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",

          // إرسال التوكن للتحقق من المستخدم
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title, // عنوان البلاغ
          description, // وصف المشكلة
          priority, // مستوى الخطورة (فقط هذا الحقل)
        }),
      });

      // تحويل الرد إلى JSON
      const data = await res.json();

      // إذا فشل الطلب
      if (!res.ok) {
        throw new Error(data.message || "فشل إنشاء البلاغ");
      }

      // =================================================
      // في حال النجاح
      // =================================================
      alert("✅ تم إنشاء البلاغ بنجاح");

      // تحويل المستخدم لصفحة البلاغات
      window.location.href = "reports.html";
    } catch (err) {
      // =================================================
      // في حال حدوث خطأ
      // =================================================
      alert("❌ " + err.message);
    }
  });
