// ===============================
// 📄 profile.js
// هذا الملف مسؤول عن:
// - حماية صفحة الملف الشخصي
// - جلب بيانات المستخدم
// - تعبئة البيانات في الصفحة
// ===============================

(async function () {
  // ===============================
  // 🔐 1️⃣ التحقق من وجود Token
  // ===============================

  // جلب التوكن من localStorage
  const token = getToken();

  // إذا لا يوجد توكن → المستخدم غير مسجّل دخول
  // يتم تحويله مباشرة لصفحة تسجيل الدخول
  if (!token) {
    redirectToLogin();
    return; // إيقاف تنفيذ الكود
  }

  // ===============================
  // 🧭 2️⃣ ضبط الـ Navbar حسب حالة الدخول
  // ===============================

  // إظهار / إخفاء روابط الـ navbar
  // (تسجيل دخول – تسجيل خروج – ملف شخصي)
  handleNavbarAuth();

  try {
    // ===============================
    // 👤 3️⃣ جلب بيانات المستخدم من السيرفر
    // ===============================

    const res = await fetch("http://localhost:5000/users/api/profile", {
      headers: {
        // إرسال التوكن للتحقق من هوية المستخدم
        Authorization: `Bearer ${token}`,
      },
    });

    const data = await res.json();

    // إذا السيرفر رفض الطلب (توكن غير صالح مثلاً)
    if (!res.ok) throw new Error("Unauthorized");

    // بيانات المستخدم القادمة من الـ Backend
    const user = data.data;

    // ===============================
    // 📝 4️⃣ تعبئة البيانات داخل الحقول
    // ===============================

    // جلب عناصر الإدخال من الصفحة
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const roleInput = document.getElementById("role");

    // تعبئة القيم مع التحقق أن العنصر موجود
    // (لتجنب أخطاء JS لو تغيرت الصفحة)
    if (nameInput) nameInput.value = user.name;
    if (emailInput) emailInput.value = user.email;
    if (roleInput) roleInput.value = user.role;
  } catch (err) {
    // ===============================
    // ❌ في حال حدوث أي خطأ
    // ===============================

    // حذف التوكن (غالبًا انتهت صلاحيته)
    clearToken();

    // إعادة التوجيه لصفحة تسجيل الدخول
    redirectToLogin();
    return;
  }

  // ===============================
  // 🚪 5️⃣ تسجيل الخروج
  // ===============================

  const logoutBtn = document.getElementById("logoutBtn");

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      // حذف التوكن
      clearToken();

      // إعادة التوجيه لصفحة تسجيل الدخول
      redirectToLogin();
    });
  }
})();
