// =========================
// 👁️ تشغيل العين السحرية (إظهار / إخفاء كلمة المرور)
// =========================

// زر العين
const togglePassword = document.getElementById("togglePassword");

// حقل كلمة المرور
const passwordInput = document.getElementById("password");

// تأكد أن العناصر موجودة بالصفحة
if (togglePassword && passwordInput) {
  togglePassword.addEventListener("click", () => {
    // الأيقونة داخل الزر (fa-eye / fa-eye-slash)
    const icon = togglePassword.querySelector("i");

    // إذا كلمة المرور مخفية
    if (passwordInput.type === "password") {
      // أظهر كلمة المرور
      passwordInput.type = "text";

      // غيّر الأيقونة إلى عين مشطوبة
      icon.classList.remove("fa-eye");
      icon.classList.add("fa-eye-slash");
    } else {
      // أخفِ كلمة المرور
      passwordInput.type = "password";

      // رجّع الأيقونة إلى عين عادية
      icon.classList.remove("fa-eye-slash");
      icon.classList.add("fa-eye");
    }
  });
}

// =========================
// 🔐 تسجيل الدخول
// =========================

// الفورم
const loginForm = document.getElementById("loginForm");

// زر الإرسال
const submitBtn = document.getElementById("submitBtn");

// رسائل الخطأ والنجاح
const errorAlert = document.getElementById("errorAlert");
const successAlert = document.getElementById("successAlert");

// عند إرسال الفورم
loginForm.addEventListener("submit", async (e) => {
  // منع إعادة تحميل الصفحة
  e.preventDefault();

  // إخفاء أي رسائل سابقة
  errorAlert.style.display = "none";
  successAlert.style.display = "none";

  // جلب القيم من الحقول
  const email = document.getElementById("email").value.trim();
  const password = passwordInput.value;

  // تفعيل حالة التحميل (spinner)
  submitBtn.classList.add("loading");
  submitBtn.disabled = true;

  try {
    // =========================
    // 1️⃣ إرسال طلب تسجيل الدخول
    // =========================
    const res = await fetch("http://localhost:5000/users/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    // تحويل الرد إلى JSON
    const data = await res.json();

    // إذا فشل الطلب
    if (!res.ok) {
      throw new Error(data.message || "فشل تسجيل الدخول");
    }

    // =========================
    // 2️⃣ حفظ التوكن (JWT)
    // =========================
    // setToken موجودة في auth.js
    setToken(data.token);

    // =========================
    // 3️⃣ جلب بيانات المستخدم (الدور)
    // =========================
    const profileRes = await fetch("http://localhost:5000/users/api/profile", {
      headers: {
        Authorization: `Bearer ${data.token}`,
      },
    });

    const profileData = await profileRes.json();

    if (!profileRes.ok) {
      throw new Error("فشل جلب بيانات المستخدم");
    }

    // استخراج الدور (user / admin / volunteer)
    const role = profileData.data.role;

    // =========================
    // 4️⃣ عرض رسالة نجاح
    // =========================
    successAlert.textContent = "✅ تم تسجيل الدخول بنجاح";
    successAlert.style.display = "block";

    // =========================
    // 5️⃣ التوجيه حسب الدور
    // =========================
    setTimeout(() => {
      if (role === "admin") {
        // لوحة التحكم
        window.location.href = "admin.html";
      } else {
        // الصفحة الرئيسية
        window.location.href = "overview.html";
      }
    }, 800);
  } catch (err) {
    // =========================
    // ❌ في حال حدوث خطأ
    // =========================
    errorAlert.textContent = "❌ " + err.message;
    errorAlert.style.display = "block";
  } finally {
    // =========================
    // 🔄 إلغاء حالة التحميل
    // =========================
    submitBtn.classList.remove("loading");
    submitBtn.disabled = false;
  }
});
