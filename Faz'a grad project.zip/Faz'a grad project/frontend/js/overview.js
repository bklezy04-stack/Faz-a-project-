// overview.js
// هذا الملف مسؤول عن التحكم بواجهة الصفحة الرئيسية (Navbar + زر إنشاء بلاغ)

// ===============================
// 📦 جلب البيانات من LocalStorage
// ===============================

// التوكن: يدل إن المستخدم مسجّل دخول
const token = localStorage.getItem("token");

// الدور (user / volunteer / admin)
// يُستخدم لتحديد الصلاحيات
const role = localStorage.getItem("role");

// ===============================
// 📌 عناصر الـ Navbar
// ===============================

// رابط الملف الشخصي
const profileLink = document.getElementById("profileLink");

// رابط تسجيل الخروج
const logoutLink = document.getElementById("logoutLink");

// رابط تسجيل الدخول
const loginLink = document.getElementById("loginLink");

// رابط إنشاء حساب
const signupLink = document.getElementById("signupLink");

// ===============================
// ➕ زر إنشاء البلاغ
// ===============================

// هذا الزر يظهر فقط للمستخدم العادي (user)
const createReportBtn = document.getElementById("createReportBtn");

// ===============================
// 🧭 منطق الـ Navbar
// ===============================

if (token) {
  // ✅ المستخدم مسجّل دخول
  // نُظهر:
  // - الملف الشخصي
  // - تسجيل الخروج
  profileLink.style.display = "block";
  logoutLink.style.display = "block";

  // نُخفي:
  // - تسجيل الدخول
  // - إنشاء حساب
  loginLink.style.display = "none";
  signupLink.style.display = "none";
} else {
  // ❌ المستخدم Guest (غير مسجّل)
  // نُخفي:
  // - الملف الشخصي
  // - تسجيل الخروج
  profileLink.style.display = "none";
  logoutLink.style.display = "none";

  // نُظهر:
  // - تسجيل الدخول
  // - إنشاء حساب
  loginLink.style.display = "block";
  signupLink.style.display = "block";
}

// ===============================
// 📝 منطق زر "إنشاء بلاغ"
// ===============================

// يظهر فقط إذا:
// 1️⃣ المستخدم مسجّل دخول
// 2️⃣ دوره user (وليس admin أو volunteer)
if (token && role === "user") {
  createReportBtn.style.display = "inline-block";
} else {
  createReportBtn.style.display = "none";
}

// ===============================
// 🚪 تسجيل الخروج
// ===============================

const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    // حذف كل البيانات (token + role)
    localStorage.clear();

    // إعادة توجيه للصفحة الرئيسية
    window.location.href = "overview.html";
  });
}
