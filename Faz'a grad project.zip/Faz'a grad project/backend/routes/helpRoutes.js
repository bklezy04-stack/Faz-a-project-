const express = require("express");
const helpController = require("../controllers/helpController");
const authController = require("../controllers/authController");

const router = express.Router();

/* user ينشئ طلب فزعة */
router.post(
  "/",
  authController.protect,
  authController.restrictTo("user"),
  helpController.createHelp
);

/* volunteer + admin يشوفوا الطلبات */
router.get(
  //مش مهم بالمشروع
  "/",
  authController.protect,
  authController.restrictTo("volunteer", "admin"),
  helpController.getAllHelp
);
router.get("/report/:reportId", helpController.getHelpByReport);

/* admin فقط يحذف */
router.delete(
  "/:id",
  authController.protect,
  authController.restrictTo("admin"),
  helpController.deleteHelp
); //مش مهم

module.exports = router;
