const express = require("express");
const userController = require("../controllers/userController");
const authController = require("../controllers/authController");

const router = express.Router();

/* ================== AUTH (PUBLIC) ================== */
router.post("/signup", authController.signup);
router.post("/login", authController.login);
router.post("/forgotPassword", authController.forgotPassword); //ما اله استخدام عملي بالمشروع
router.patch("/resetPassword/:token", authController.resetPassword); //ما اله استخدام عملي بالمشروع

/* ================== USER (PROTECTED) ================== */
router.get("/profile", authController.protect, userController.getProfile);

router.patch(
  "/updateMyPassword",
  authController.protect,
  authController.updatePassword
); //ملهوش استخدام عملي بالمشروع

router.patch("/updateMe", authController.protect, userController.updateMe);

/* ================== ADMIN ONLY ================== */
router.delete(
  "/:id",
  authController.protect,
  authController.restrictTo("admin"),
  userController.deleteUser
);

router.get(
  "/",
  authController.protect,
  authController.restrictTo("admin"),
  userController.getAllUser
);

router.get(
  "/:id",
  authController.protect,
  authController.restrictTo("admin"),
  userController.getUser
);

module.exports = router;
