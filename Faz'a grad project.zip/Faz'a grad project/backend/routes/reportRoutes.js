const express = require("express");
const reportController = require("../controllers/reportController");
const authController = require("../controllers/authController");

const router = express.Router();

/* user ينشئ report */
router.post(
  "/",
  authController.protect,
  authController.restrictTo("user"),
  reportController.createReport
);

router.get("/", authController.protect, reportController.getAllReports);

router.get("/:id", authController.protect, reportController.getReport);
router.get(
  "/my-reports",
  authController.protect,
  reportController.getMyReports
);

/* admin فقط */
router.delete(
  "/:id",
  authController.protect,
  authController.restrictTo("admin"),
  reportController.deleteReport
);

// PATCH /reports/api/:id/status
router.patch(
  "/:id/status",
  authController.protect,
  authController.restrictTo("admin"),
  reportController.updateReportStatus
);

router.patch("/:id", authController.protect, reportController.updateReport);

module.exports = router;
