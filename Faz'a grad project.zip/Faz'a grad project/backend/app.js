const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const fs = require("fs");
const { json } = require("stream/consumers");
const morgan = require("morgan");
const cors = require("cors");
const statsRoutes = require("./routes/statsRoutes");
const reportRoutes = require("./routes/reportRoutes");
const helpRoutes = require("./routes/helpRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));
app.use(cors());
console.log(process.env.NODE_ENV); //log=>dev
if (process.env.NODE_ENV === "development") {
  app.use(morgan("dev"));
}
//app.use(express.static(`${__dirname}/public`));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "frontend", "overview.html"));
});

app.use((req, res, next) => {
  console.log("Hello from the middleware");
  next();
});

app.use((req, res, next) => {
  req.requestTime = new Date().toISOString();
  console.log(req.requestTime);
  next();
});

app.use("/users/api", userRoutes);
//app.use("/helps/api", helpRoutes);
app.use("/reports/api", reportRoutes);
app.use("/api/v1/stats", statsRoutes);
module.exports = app;

/*
=====================================================
📌 app.js – وظيفة الملف
=====================================================

هذا الملف مسؤول عن تهيئة تطبيق Express
وربط جميع أجزاء المشروع مع بعضها.

-----------------------------------------------------
🧠 المهام الرئيسية:
-----------------------------------------------------

1️⃣ إنشاء تطبيق Express
-----------------------------------------------------
- إنشاء instance من Express
- تجهيز التطبيق لاستقبال الطلبات

-----------------------------------------------------
2️⃣ Middleware الأساسية
-----------------------------------------------------
- express.json():
  لتحويل body القادم بصيغة JSON إلى كائن JS

- express.static():
  لربط مجلد frontend مع السيرفر
  وتمكين فتح صفحات HTML عبر:
  http://localhost:PORT

- cors():
  للسماح بالطلبات من متصفحات أو مصادر مختلفة

- morgan (في وضع development):
  لعرض تفاصيل الطلبات في الـ console

-----------------------------------------------------
3️⃣ Route الصفحة الرئيسية "/"
-----------------------------------------------------
- عند زيارة:
  http://localhost:PORT
- يتم عرض صفحة overview.html
- تعتبر نقطة الدخول الرئيسية للموقع

-----------------------------------------------------
4️⃣ Middleware مخصصة
-----------------------------------------------------
- Middleware لطباعة رسالة عند كل request
- Middleware لإضافة وقت الطلب (requestTime)
- مفيدة للتجربة، التتبع، والتصحيح (debugging)

-----------------------------------------------------
5️⃣ ربط مسارات الـ API
-----------------------------------------------------
- /users/api    → إدارة المستخدمين والمصادقة
- /helps/api    → إدارة المساعدات والمتطوعين
- /reports/api  → إدارة البلاغات

كل مسار يتم توجيهه إلى controller خاص به

-----------------------------------------------------
📌 ملاحظة مهمة:
-----------------------------------------------------
هذا الملف لا يشغل السيرفر مباشرة،
بل يتم استيراده في server.js
حيث يتم تشغيل التطبيق والاستماع على المنفذ.

=====================================================
*/
