//                                  //
//                                  //
//هاض الملف مسؤول عن تشغيل السيرفر//
const path = require("path");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const app = require("./app");

dotenv.config({ path: path.join(__dirname, "config.env") });

const DB = process.env.DATABASE.replace(
  "<PASSWORD>",
  process.env.DATABASE_PASSWORD
);

// 🔹 اتصال قاعدة البيانات
mongoose
  .connect(DB)
  .then(() => console.log("📢 MongoDB Connected"))
  .catch((err) => console.log("❌ Connection error:", err));

// 🔹 تشغيل السيرفر
const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`⚡ App running on port ${port}`);
});
/*DATABASE_PASSWORD=bauTeamFazaa
DATABASE=mongodb+srv://mohdad2004_db_user:<PASSWORD>@fazaa.nr6cieb.mongodb.net/fazaa*/
