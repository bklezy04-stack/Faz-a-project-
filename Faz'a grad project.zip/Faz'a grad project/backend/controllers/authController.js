const crypto = require("crypto"); //تشفير التوكن إعادة تعيين كلمة المرور //مش مهم بالمشروع عمليا//
const jwt = require("jsonwebtoken"); //إنشاء والتحقق من JWT مهم كثير
const User = require("../models/userModel");
const { promisify } = require("util");
const bcrypt = require("bcryptjs"); //تشفير ومقارنة كلمات المرور +مهم كثير

const signToken = (id) => {
  /*
تنشئ JWT يحتوي فقط على:id المستخدم

تستخدم: secret من env
+
تعين 
مدة صلاحية محددة 
*/
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  });
};

exports.signup = async (req, res, next) => {
  try {
    const newUser = await User.create({
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
      passwordConfirm: req.body.passwordConfirm,
      passwordChangedAt: req.body.passwordChangedAt,
      role: req.body.role,
    });

    const token = signToken(newUser._id);

    res.status(201).json({
      status: "success",
      token,
      data: newUser,
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // 1) تحقق وجود الإيميل والباسورد
    if (!email || !password) {
      return res.status(400).json({
        status: "fail",
        message: "Please provide email and password",
      });
    }

    // 2) تحقق من وجود المستخدم في DB + اختر كلمة المرور لأننا مخفيينها
    /*كلمة المرور مخفية افتراضيًا في schema + نطلبها صراحة هنا فقط*/
    const user = await User.findOne({ email }).select("+password");

    console.log(user);
    if (!user) {
      return res.status(401).json({
        status: "fail",
        message: "Incorrect email or password",
      });
    }

    // 3) تحقق من صحة كلمة المرور
    //مقارنة آمنة باستخدام bcrypt
    //correctPassword()هاي معرفة بالuserModel بنستدعيها هون عشان تتاكد كلمة المرور صحيحة
    const correct = await user.correctPassword(password, user.password);
    if (!correct) {
      return res.status(401).json({
        status: "fail",
        message: "Incorrect email or password",
      });
    }

    // 4) إذا كل شيء صح → اعمل JWT
    //JWT هو اللي بعطي صلاحية لاستخدام الموقع
    //signToken هاي اللي معرفينها فوق وظيفتها تنشئ jwt
    const token = signToken(user._id);

    // 5) أرسل الـ response
    res.status(200).json({
      status: "success",
      token,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};
exports.protect = async (req, res, next) => {
  try {
    // 1) Getting token and check if it's there
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];
    }
    if (!token) {
      return res.status(401).json({
        status: "fail",
        message: "You are not logged in! Please log in to get access.",
      });
    }

    // 2) Verification token

    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);

    // 3) Check if user still exists
    const currentUser = await User.findById(decoded.id);
    if (!currentUser) {
      return res.status(401).json({
        status: "fail",
        message: "The user belonging to this token no longer exists.",
      });
    }

    // 4) Check if user changed password after the token was issued
    if (currentUser.changedPasswordAfter(decoded.iat)) {
      return res.status(401).json({
        status: "fail",
        message: "User recently changed password! Please log in again.",
      });
    }

    // GRANT ACCESS
    //اذا عديت كل الخطوات اللي قبل بتقدر تفوت الموقع
    req.user = currentUser;
    next();
  } catch (err) {
    return res.status(401).json({
      status: "fail",
      message: "Invalid token or token expired",
    });
  }
};

exports.restrictTo = (...roles) => {
  //المسؤول عن تحديد اولويات اللي بستخدمو الموقع
  //تحديد صلاحيات كل اللي بستخدمو الموقع حسب
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        status: "fail",
        message: "ليس لديك صلاحية",
      });
    }
    next();
  };
};

exports.forgotPassword = async (req, res) => {
  //مش مهم بالمشروع عمليا
  try {
    // 1) Get user based on POSTed email
    const user = await User.findOne({ email: req.body.email });

    if (!user) {
      return res.status(404).json({
        status: "fail",
        message: "لا يوجد مستخدم بهذا البريد الإلكتروني",
      });
    }

    // 2) Generate the reset token
    const resetToken = user.createPasswordResetToken();
    await user.save({ validateBeforeSave: false });

    // 3) Create reset URL
    const resetURL = `${req.protocol}://${req.get(
      "host"
    )}/api/users/resetPassword/${resetToken}`;

    // 4) Send token via email (مؤقتًا response)
    await sendEmail({
      email: user.email,
      subject: "إعادة تعيين كلمة المرور",
      message: `اضغط على الرابط لإعادة تعيين كلمة المرور:\n${resetURL}`,
    });

    res.status(200).json({
      status: "success",
      message: "تم إرسال رابط إعادة تعيين كلمة المرور",
      resetURL, // ❗ احذفه لما تفعل الإيميل
    });
  } catch (err) {
    return res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};

const sendEmail = require("../utils/email"); // لو حاب تبعت رسالة تأكيد بعد تغيير الباسورد

exports.resetPassword = async (req, res) => {
  //مش مهم بالمشروع عمليا
  try {
    // 1️⃣ تشفير الـ token المرسل للمقارنة مع DB
    const hashedToken = crypto
      .createHash("sha256")
      .update(req.params.token)
      .digest("hex");

    // 2️⃣ البحث عن المستخدم بالـ token وصلاحية الوقت
    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: { $gt: Date.now() },
    });

    if (!user) {
      return res.status(400).json({
        status: "fail",
        message: "Token غير صالح أو انتهت صلاحيته",
      });
    }

    // 3️⃣ تحديث كلمة المرور
    user.password = req.body.password;
    user.passwordConfirm = req.body.passwordConfirm;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    user.passwordChangedAt = Date.now();

    await user.save();

    // 4️⃣ عمل JWT جديد بعد تغيير الباسورد
    const jwt = require("jsonwebtoken");
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });

    res.status(200).json({
      status: "success",
      message: "تم تغيير كلمة المرور بنجاح",
      token,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};

exports.updatePassword = async (req, res) => {
  //مش مهم بالمشروع عمليا
  try {
    const userId = req.user.id; // مستخدم محمي عبر middleware protect
    const { currentPassword, newPassword, newPasswordConfirm } = req.body;

    // 1️⃣ جلب المستخدم مع كلمة المرور
    const user = await User.findById(userId).select("+password");

    // 2️⃣ التحقق من كلمة المرور الحالية
    if (!(await user.correctPassword(currentPassword, user.password))) {
      return res.status(401).json({
        status: "fail",
        message: "كلمة المرور الحالية غير صحيحة",
      });
    }

    // 3️⃣ تعيين كلمة المرور الجديدة
    user.password = newPassword;
    user.passwordConfirm = newPasswordConfirm;

    await user.save(); // 🔥 pre("save") ستعمل تلقائيًا لتشفير كلمة المرور وتحديث passwordChangedAt

    // 4️⃣ إنشاء JWT جديد
    const token = signToken(user._id);

    // 5️⃣ إرسال الـ response
    res.status(200).json({
      status: "success",
      token,
      message: "تم تحديث كلمة المرور بنجاح",
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};

/*
=====================================================
📌 Auth Controller – شرح تفصيلي
=====================================================

هذا الملف مسؤول عن المصادقة (Authentication)
والتفويض (Authorization) في النظام.

يعتمد على:
- JWT
- bcrypt
- crypto
- MongoDB + Mongoose

-----------------------------------------------------
1️⃣ signToken
-----------------------------------------------------
- دالة مساعدة لإنشاء JWT
- تحتوي فقط على id المستخدم
- تستخدم secret ومدة صلاحية من env

-----------------------------------------------------
2️⃣ signup
-----------------------------------------------------
- تسجيل مستخدم جديد
- حفظه في قاعدة البيانات
- إنشاء JWT مباشرة بعد التسجيل
- (ملاحظة: تمرير role من body خطر في الإنتاج)

-----------------------------------------------------
3️⃣ login
-----------------------------------------------------
- تسجيل الدخول
- التحقق من:
  - وجود الإيميل والباسورد
  - وجود المستخدم
  - صحة كلمة المرور
- إنشاء JWT عند النجاح

-----------------------------------------------------
4️⃣ protect
-----------------------------------------------------
- Middleware لحماية المسارات
- يتحقق من:
  1. وجود التوكن
  2. صحة التوكن
  3. وجود المستخدم
  4. عدم تغيير كلمة المرور بعد إصدار التوكن
- يضيف user إلى req

-----------------------------------------------------
5️⃣ restrictTo
-----------------------------------------------------
- Middleware لتحديد الصلاحيات
- يمنع الوصول إذا role غير مصرح له

-----------------------------------------------------
6️⃣ forgotPassword
-----------------------------------------------------
- إنشاء token لإعادة تعيين كلمة المرور
- تخزينه مشفر في DB
- تحديد وقت انتهاء
- إرسال رابط إعادة التعيين (مؤقتًا في response)

-----------------------------------------------------
7️⃣ resetPassword
-----------------------------------------------------
- إعادة تعيين كلمة المرور باستخدام token
- التحقق من:
  - صحة التوكن
  - عدم انتهاء صلاحيته
- تحديث كلمة المرور
- حذف التوكن
- إنشاء JWT جديد

-----------------------------------------------------
8️⃣ updatePassword
-----------------------------------------------------
- تغيير كلمة المرور لمستخدم مسجل دخول
- التحقق من كلمة المرور الحالية
- تعيين كلمة مرور جديدة
- إنشاء JWT جديد بعد التحديث

=====================================================
*/
