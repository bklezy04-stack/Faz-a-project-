const Report = require("../models/reportModel");
const User = require("../models/userModel");

exports.getPlatformStats = async (req, res) => {
  try {
    const helpedReports = await Report.countDocuments({
      status: "completed",
    });

    const activeVolunteers = await User.countDocuments({
      role: "volunteer",
    });

    res.status(200).json({
      status: "success",
      data: {
        helpedReports,
        activeVolunteers,
      },
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};
