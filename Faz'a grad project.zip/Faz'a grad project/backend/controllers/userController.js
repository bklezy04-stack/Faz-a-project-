const User = require("../models/userModel");
const Report = require("../models/reportModel");
const Help = require("../models/helpModel");
// دالة لمفلترة الحقول المسموح بتحديثها
const filterObj = (obj, ...allowedFields) => {
  const newObj = {};
  Object.keys(obj).forEach((el) => {
    if (allowedFields.includes(el)) newObj[el] = obj[el];
  });
  return newObj;
};

// جلب جميع المستخدمين
exports.getAllUser = async (req, res) => {
  try {
    const users = await User.find();
    res.json({ status: "success", results: users.length, data: users });
  } catch (err) {
    res.status(500).json({ status: "error", message: err.message });
  }
};

// جلب مستخدم حسب ID
exports.getUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user)
      return res
        .status(404)
        .json({ status: "error", message: "المستخدم غير موجود" });

    res.json({ status: "success", data: user });
  } catch (err) {
    res.status(500).json({ status: "error", message: err.message });
  }
};

// حذف مستخدم
exports.deleteUser = async (req, res) => {
  //بس الادمن اللي اله صلاحية
  try {
    const userId = req.params.id;

    // 1. تأكد أن المستخدم موجود
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // 2. حذف كل البلاغات التابعة للمستخدم
    await Report.deleteMany({ user: userId });

    // 3. حذف كل الـHelps التي قام بها هذا المتطوع
    await Help.deleteMany({ volunteer: userId });

    // 4. حذف المستخدم نفسه
    await User.findByIdAndDelete(userId);

    res.json({ message: "User and related data deleted successfully" });
  } catch (err) {
    console.error("Delete User Error:", err);
    res.status(500).json({
      message: "Error deleting user",
      error: err.message,
    });
  }
};

exports.getProfile = (req, res) => {
  res.status(200).json({
    status: "success",
    data: req.user,
  });
};

// تحديث بيانات المستخدم نفسه
exports.updateMe = async (req, res) => {
  //مش مهم بالمشروع
  //مش مهم عملي
  try {
    // 1️⃣ منع تغيير كلمة المرور هنا
    if (req.body.password || req.body.passwordConfirm) {
      return res.status(400).json({
        status: "fail",
        message: "لا يمكن تغيير كلمة المرور من هنا. استخدم /updateMyPassword",
      });
    }

    // 2️⃣ فلترة الحقول المسموح بتحديثها (name و email عادة)
    const filteredBody = filterObj(req.body, "name", "email");

    // 3️⃣ تحديث المستخدم
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      filteredBody,
      {
        new: true, // لإرجاع المستند الجديد بعد التحديث
        runValidators: true, // تشغيل validators
      }
    );

    res.status(200).json({
      status: "success",
      data: {
        user: updatedUser,
      },
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};

/*
=====================================================
📌 User Controller – شرح تفصيلي
=====================================================

هذا الملف مسؤول عن إدارة المستخدمين في النظام.

🔹 يشمل:
- جلب المستخدمين
- حذف المستخدم
- الملف الشخصي
- تحديث بيانات المستخدم نفسه
- حماية الحقول الحساسة

-----------------------------------------------------
1️⃣ filterObj
-----------------------------------------------------
- دالة مساعدة لفلترة الحقول المسموح بتحديثها
- تمنع المستخدم من تعديل حقول غير مصرح بها
- تُستخدم خصوصًا في updateMe

-----------------------------------------------------
2️⃣ getAllUser
-----------------------------------------------------
- جلب جميع المستخدمين من قاعدة البيانات
- غالبًا مخصص للأدمن
- يعيد عدد المستخدمين + البيانات

-----------------------------------------------------
3️⃣ getUser
-----------------------------------------------------
- جلب مستخدم واحد حسب ID
- يعيد 404 إذا لم يكن موجود

-----------------------------------------------------
4️⃣ deleteUser
-----------------------------------------------------
- حذف مستخدم بشكل آمن
- الخطوات:
  1. التأكد من وجود المستخدم
  2. حذف جميع البلاغات التابعة له
  3. حذف جميع المساعدات التي قام بها
  4. حذف المستخدم نفسه
- يمنع وجود بيانات يتيمة في النظام

-----------------------------------------------------
5️⃣ getProfile
-----------------------------------------------------
- جلب بيانات المستخدم الحالي
- يعتمد على req.user القادم من JWT
- يستخدم لصفحة "ملفي الشخصي"

-----------------------------------------------------
6️⃣ updateMe
-----------------------------------------------------
- تحديث بيانات المستخدم نفسه
- يمنع تغيير كلمة المرور
- يسمح فقط بتعديل name و email
- يستخدم filterObj للحماية
- يشغل validators عند التحديث

=====================================================
*/
