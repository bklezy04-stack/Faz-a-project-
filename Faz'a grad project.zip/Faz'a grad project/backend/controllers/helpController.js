const Help = require("../models/helpModel");

// إنشاء طلب مساعدة
exports.createHelp = async (req, res) => {
  //مش مهم
  try {
    const help = await Help.create(req.body);
    res.status(201).json({
      status: "success",
      data: help,
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};

// جميع طلبات المساعدة
exports.getAllHelp = async (req, res) => {
  //مش مهم
  try {
    const help = await Help.find().populate("report").populate("volunteer");
    res.status(200).json({
      status: "success",
      results: help.length,
      data: help,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};
exports.deleteHelp = async (req, res) => {
  // مهم
  try {
    const help = await Help.findByIdAndDelete(req.params.id);

    if (!help) {
      return res.status(404).json({ message: "Help not found" });
    }

    res.json({ message: "Help deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting help", error: err });
  }
};

exports.updateHelpStatus = async (req, res) => {
  try {
    const { status } = req.body;

    // الحالات المسموحة
    const allowedStatuses = ["pending", "accepted", "completed", "rejected"];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        status: "fail",
        message: "Invalid status",
      });
    }

    const help = await Help.findById(req.params.id);

    if (!help) {
      return res.status(404).json({
        status: "fail",
        message: "Help not found",
      });
    }

    // أول قبول → تثبيت المساعد
    if (status === "accepted" && !help.helper && req.user) {
      help.helper = req.user.id;
    }

    help.status = status;
    await help.save();

    res.status(200).json({
      status: "success",
      data: help,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: "Server error",
    });
  }
};
exports.getHelpByReport = async (req, res) => {
  //هاي مهمة
  try {
    const help = await Help.findOne({
      report: req.params.reportId,
    }).populate("volunteer", "name email role");

    // إذا ما في متطوع لسه → هذا طبيعي
    if (!help) {
      return res.status(200).json({
        status: "success",
        data: null,
      });
    }

    res.status(200).json({
      status: "success",
      data: help,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: "خطأ في جلب المتطوع",
    });
  }
};
