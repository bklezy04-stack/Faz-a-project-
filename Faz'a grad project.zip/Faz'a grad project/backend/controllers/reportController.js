//1️⃣ استيراد الـ Models
const Report = require("../models/reportModel");
const Help = require("../models/helpModel");

// 2️⃣ createReport – إنشاء بلاغ جديد
exports.createReport = async (req, res) => {
  try {
    const report = await Report.create({
      //بيانات تأتي من الـ frontend
      title: req.body.title,
      description: req.body.description,
      location: req.body.location,
      priority: req.body.priority,
      user: req.user.id, // 👤ربط البلاغ بصاحب الطلب
    });

    res.status(201).json({
      status: "success",
      data: report,
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};

// جميع البلاغات
exports.getAllReports = async (req, res) => {
  try {
    let query = {};

    //اذا كان المستخدم من نوع "يوزر" ما بقدر يشوف الا البلاغات اللي هو منزلها
    /*إذا متطوع أو أدمن:يرى كل البلاغات*/
    if (req.user.role === "user") {
      query.user = req.user.id;
    }

    const reports = await Report.find(query);

    res.status(200).json({
      status: "success",
      data: reports,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: "فشل جلب البلاغات",
    });
  }
};

/*
// بلاغ واحد نسخة قديمة
exports.getReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id);

    if (!report) {
      return res
        .status(404)
        .json({ status: "fail", message: "بلاغ غير موجود" });
    }

    res.status(200).json({
      status: "success",
      data: report,
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};
*/
//بلاغ واحد محدث
exports.getReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id)
      //جلب بيانات المستخدم والمتطوع
      .populate("user", "name email role")
      .populate("volunteer", "name email role");

    if (!report) {
      return res.status(404).json({
        status: "fail",
        message: "البلاغ غير موجود",
      });
    }

    res.status(200).json({
      status: "success",
      data: report,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: "خطأ في جلب تفاصيل البلاغ",
    });
  }
};

exports.updateReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        status: "fail",
        message: "البلاغ غير موجود",
      });
    }

    // 🔒 إذا البلاغ مكتمل → ممنوع أي تعديل
    if (report.status === "completed") {
      return res.status(400).json({
        status: "fail",
        message: "البلاغ مغلق",
      });
    }

    // =========================
    // 🤝 volunteer يقبل البلاغ
    // =========================
    if (req.user.role === "volunteer") {
      if (report.status !== "pending") {
        return res.status(400).json({
          status: "fail",
          message: "تم التعامل مع البلاغ مسبقًا",
        });
      }

      if (req.body.status !== "accepted") {
        return res.status(403).json({
          status: "fail",
          message: "المتطوع يستطيع فقط قبول البلاغ",
        });
      }

      report.status = "accepted";
      report.volunteer = req.user.id;
    }

    // =========================
    // 👤 user يؤكد الإتمام
    // =========================
    if (req.user.role === "user") {
      //بقدر المستخدم يغلق البلاغ بشرط هو صاحب البلاغ + انقبل من متطوع
      if (
        req.body.status === "completed" &&
        report.status === "accepted" &&
        report.user.toString() === req.user.id
      ) {
        report.status = "completed";
      } else {
        return res.status(403).json({
          status: "fail",
          message: "غير مصرح لك",
        });
      }
    }

    await report.save();

    res.status(200).json({
      status: "success",
      data: report,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: err.message,
    });
  }
};

exports.deleteReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id);

    if (!report) {
      return res.status(404).json({ message: "Report not found" });
    }

    // 1. حذف كل الـHelps المرتبطة مع هذا البلاغ
    await Help.deleteMany({ report: report._id });

    // 2. حذف البلاغ نفسه
    await Report.findByIdAndDelete(report._id);

    res.json({ message: "Report and related helps deleted successfully" });
  } catch (err) {
    console.error("Delete Error:", err);
    res.status(500).json({
      message: "Error deleting report",
      error: err.message,
    });
  }
};

exports.getMyReports = async (req, res) => {
  //مش مهم بالمشروع
  try {
    const reports = await Report.find({
      user: req.user.id,
    });

    res.status(200).json({
      status: "success",
      data: reports,
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      message: "فشل جلب بلاغات المستخدم",
    });
  }
};

exports.updateReportStatus = async (req, res) => {
  const { status } = req.body;

  const report = await Report.findByIdAndUpdate(
    req.params.id,
    { status },
    { new: true, runValidators: true }
  );

  if (!report) {
    return res.status(404).json({
      status: "fail",
      message: "البلاغ غير موجود",
    });
  }

  res.status(200).json({
    status: "success",
    data: report,
  });
};

/*
=====================================================
📌 Report Controller – شرح تفصيلي
=====================================================

هذا الملف مسؤول عن إدارة البلاغات (Reports) في مشروع فزعة.

🔹 يعتمد على:
- JWT Authentication (req.user)
- Roles (user / volunteer)
- MongoDB + Mongoose

-----------------------------------------------------
1️⃣ createReport
-----------------------------------------------------
- إنشاء بلاغ جديد
- يتم ربط البلاغ بالمستخدم من خلال req.user.id
- البيانات تأتي من body
- يُستخدم عند POST /reports/api

-----------------------------------------------------
2️⃣ getAllReports
-----------------------------------------------------
- جلب البلاغات حسب نوع المستخدم
- user → يرى بلاغاته فقط
- volunteer / admin → يرون جميع البلاغات
- يتم بناء query ديناميكي

-----------------------------------------------------
3️⃣ getReport
-----------------------------------------------------
- جلب بلاغ واحد حسب ID
- يستخدم populate لجلب:
  - بيانات صاحب البلاغ
  - بيانات المتطوع
- مفيد لصفحة تفاصيل البلاغ

-----------------------------------------------------
4️⃣ updateReport
-----------------------------------------------------
- التحكم في تغيير حالة البلاغ
- قواعد صارمة:
  🔒 لا تعديل بعد completed

  🤝 volunteer:
    - يستطيع فقط قبول البلاغ
    - لا يستطيع الإغلاق أو التعديل

  👤 user:
    - يستطيع فقط إغلاق البلاغ
    - بشرط:
      - البلاغ مقبول
      - هو صاحب البلاغ

-----------------------------------------------------
5️⃣ deleteReport
-----------------------------------------------------
- حذف بلاغ
- يتم أولًا حذف كل المساعدات المرتبطة به
- ثم حذف البلاغ نفسه
- يمنع وجود بيانات يتيمة في قاعدة البيانات

-----------------------------------------------------
6️⃣ getMyReports
-----------------------------------------------------
- جلب جميع بلاغات المستخدم الحالي
- يعتمد على req.user.id
- مفيد لواجهة "بلاغاتي"

=====================================================
*/
