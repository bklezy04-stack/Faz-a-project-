const mongoose = require("mongoose");
//كل اشي هون مش مهم
const helpSchema = new mongoose.Schema({
  report: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Report",
    required: true,
  },
  volunteer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  message: {
    type: String,
    default: "متطوع جاهز للمساعدة",
  },
  status: {
    type: String,
    enum: ["pending", "accepted", "completed", "rejected"],
    default: "pending",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Help = mongoose.model("Help", helpSchema);
module.exports = Help;
