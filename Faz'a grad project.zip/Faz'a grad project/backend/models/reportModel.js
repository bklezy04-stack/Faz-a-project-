const mongoose = require("mongoose");

const reportSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "يجب أن يكون للبلاغ عنوان"],
  },

  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },

  // 👈 المتطوع الذي قبل البلاغ
  volunteer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null,
  },

  description: {
    type: String,
    required: [true, "يجب أن يكون للبلاغ وصف"],
  },

  location: {
    type: String,
    default: "غير محدد",
  },

  status: {
    type: String,
    enum: [
      "pending", // بلاغ جديد
      "accepted", // متطوع قبله
      "completed", // تمت المساعدة
    ],
    default: "pending",
  },
  priority: {
    type: String,
    enum: ["low", "medium", "high", "critical"],
    default: "medium",
  },

  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("Report", reportSchema);
