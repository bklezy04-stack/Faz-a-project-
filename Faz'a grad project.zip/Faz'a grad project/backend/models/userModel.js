const crypto = require("crypto");
const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "يجب إدخال الاسم"],
  },
  email: {
    type: String,
    required: [true, "يجب إدخال البريد الإلكتروني"],
    unique: true,
    lowercase: true,
    validate: [validator.isEmail, "please provide valid email"],
  },
  password: {
    type: String,
    required: [true, "يجب تعريف كلمة مرور"],
    minlength: 8,
    select: false,
  },
  passwordConfirm: {
    type: String,
    required: [true, "يجب تأكيد كلمة المرور"],
    validate: {
      //this only work on CREATE and SAVE
      validator: function (el) {
        return el === this.password;
      },
      message: "passwords are not the same!",
    },
  },
  role: {
    type: String,
    enum: ["user", "volunteer", "admin"],
    default: "user",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  passwordChangedAt: Date, //------------
  passwordResetToken: String, //---------مش مهمات بالمشروع
  passwordResetExpires: Date, //---------
});

userSchema.pre("save", async function () {
  //لما تعمل انشاء حساب قبل ما يحفظ بياناتك بدخل هون
  //only run this function if password is actually modified
  if (!this.isModified("password")) return;

  //hash the password with cost 12
  this.password = await bcrypt.hash(this.password, 12); //تشفير كلمة السر

  //delete passwo    rdConfirm field
  this.passwordConfirm = undefined; //هاي وظيفتها بس للتاكد فش داعي تتشفر وتتخزن بالداتابيس
});

userSchema.pre("save", function () {
  //هاي في حال تغيير كلمة السر بنحتاجها يعني عمليا مش مهمة بالمشروع
  if (!this.isModified("password") || this.isNew) return;

  this.passwordChangedAt = Date.now() - 1000;
});

userSchema.methods.correctPassword = async function (
  //مش مهم بالمشروع
  candidatePassword,
  userPassword
) {
  return await bcrypt.compare(candidatePassword, userPassword);
};

userSchema.methods.changedPasswordAfter = function (JWTTimestamp) {
  //مش مهم بالمشروع
  console.log("JWT Timestamp (iat):", JWTTimestamp);

  if (this.passwordChangedAt) {
    const changedTimestamp = parseInt(
      this.passwordChangedAt.getTime() / 1000,
      10
    );

    console.log("Password changed at:", changedTimestamp);

    const result = JWTTimestamp < changedTimestamp;
    console.log("Token invalid because password changed?", result);

    return result;
  }

  console.log("Password was never changed");
  return false;
};

userSchema.methods.createPasswordResetToken = function () {
  //مش مهم عمليا  بالمشروع
  // 1) Generate random token (unhashed)
  const resetToken = crypto.randomBytes(32).toString("hex");

  // 2) Hash token and save to DB
  this.passwordResetToken = crypto
    .createHash("sha256")
    .update(resetToken)
    .digest("hex");

  // 3) Set expiration time (10 minutes)
  this.passwordResetExpires = Date.now() + 10 * 60 * 1000;

  // 4) Return the unhashed token (to send via email)
  return resetToken;
};

const User = mongoose.model("User", userSchema);
module.exports = User;
